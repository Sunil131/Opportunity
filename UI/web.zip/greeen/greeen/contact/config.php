<?php
// To
define("WEBMASTER_EMAIL", 'name@email.com');
?>
